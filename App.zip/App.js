import './App.css';
import TodaysPlan from './03/TodaysPlan';
import BooleanComponent from './03/BooleanComponent';
import StateExample from './03/StateExample';
import Counter from './counter/Counter';

function App() {
  return (
    <div className="App">
      <Counter></Counter>
    </div>
  );
}

export default App;
