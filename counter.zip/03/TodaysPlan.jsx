import React from 'react';

class TodaysPlan extends React.Component{
    render(){
        return(
            <div classname="message-container">가보자고</div>
        )
    }
}

export default TodaysPlan;